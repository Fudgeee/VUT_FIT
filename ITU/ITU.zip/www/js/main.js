document.addEventListener('DOMContentLoaded', () => {
	naja.uiHandler.selector=':not(.noajax)'
	naja.initialize();
	console.log(naja);
});
