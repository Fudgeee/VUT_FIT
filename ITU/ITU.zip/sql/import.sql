-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: localhost    Database: itu
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `car`
--

DROP TABLE IF EXISTS `car`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `car` (
  `ID` int unsigned NOT NULL AUTO_INCREMENT,
  `brand` varchar(45) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `drive` varchar(45) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT 'Diesel',
  `tank` int unsigned NOT NULL DEFAULT '75',
  `seats` int unsigned NOT NULL DEFAULT '4',
  `prevodovka` varchar(45) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT 'Manuálna',
  `photopath` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `dojezd` int unsigned NOT NULL DEFAULT '100',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `car`
--

LOCK TABLES `car` WRITE;
/*!40000 ALTER TABLE `car` DISABLE KEYS */;
INSERT INTO `car` VALUES (1,'BMW M3','Diesel',55,5,'Automatická','ITUimg/bmw_m3.jpg',400),(2,'Audi A4','Diesel',75,5,'Automatická','ITUimg/audi_a4.jpg',700),(3,'Škoda Scala','Diesel',75,4,'Manuálna','ITUimg/Skoda_Scala.jpg',700),(4,'Škoda Fabia','Diesel',80,5,'Manuálna','ITUimg/skoda_fabia.jpg',500),(5,'Kia Ceed','Diesel',55,5,'Manuálna','ITUimg/kia.jpg',400),(6,'Hyundai Ioniq','Elektromobil',60,5,'Automatická','ITUimg/hyundai.jpg',100),(7,'Fiat 500','Elektromobil',60,2,'Manuálna','ITUimg/fiat.jpeg',100),(8,'Tesla S','Elektromobil',55,5,'Automatická','ITUimg/tesla_s.jpg',400),(9,'Renault Megane E-TECH','Elektromobil',60,5,'Manuálna','ITUimg/renault.jpg',100),(10,'Volkswagen e-Golf','Elektromobil',88,4,'Automatická','ITUimg/golf1.jpg',100),(11,'Volkswagen e-Golf','Elektromobil',90,4,'Automatická','ITUimg/golf.webp',100);
/*!40000 ALTER TABLE `car` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reservation`
--

DROP TABLE IF EXISTS `reservation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reservation` (
  `ID` int unsigned NOT NULL AUTO_INCREMENT,
  `ID_car` int unsigned NOT NULL,
  `ID_user` int unsigned NOT NULL,
  `datum_rezervacie` datetime NOT NULL,
  `datum_vratenia` datetime NOT NULL,
  `dovod` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT 'Služební jízda',
  `schvalene` int unsigned DEFAULT '0',
  PRIMARY KEY (`ID` DESC),
  KEY `ID_car` (`ID_car`),
  KEY `ID_user` (`ID_user`),
  CONSTRAINT `reservation_ibfk_1` FOREIGN KEY (`ID_car`) REFERENCES `car` (`ID`) ON DELETE CASCADE,
  CONSTRAINT `reservation_ibfk_2` FOREIGN KEY (`ID_user`) REFERENCES `user` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reservation`
--

LOCK TABLES `reservation` WRITE;
/*!40000 ALTER TABLE `reservation` DISABLE KEYS */;
INSERT INTO `reservation` VALUES (32,4,3,'2021-12-02 13:36:00','2021-12-02 17:36:00','Služební jízda',2),(31,3,3,'2021-12-02 13:36:00','2021-12-02 17:36:00','Služební jízda',2),(30,3,3,'2021-12-02 13:36:00','2021-12-02 17:36:00','Služební jízda',1),(29,2,3,'2021-12-02 13:36:00','2021-12-02 17:36:00','Služební jízda',1),(28,1,2,'2021-12-02 10:18:00','2021-12-02 14:18:00','Služební jízda',2),(27,3,2,'2021-12-02 04:02:00','2021-12-02 08:02:00','Služební jízda',2);
/*!40000 ALTER TABLE `reservation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `ID` int unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `role` varchar(48) NOT NULL DEFAULT 'user',
  `name` varchar(48) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `surname` varchar(48) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `town` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `street` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `pc` varchar(8) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `phone` varchar(16) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (2,'BLEH@EMAIL.COM','$2y$10$WLcChRsei6kBo27zlR0j7epDVm4uTGckK5lRTbzKu/0QcRBewv/hm','manager',NULL,NULL,NULL,NULL,NULL,NULL),(3,'admin@admin.cz','$2y$10$w0aYEwJaN8I138Bjh5NYS.AvOpr9OGm.ZYGcSfPHdoaRIWEdZaObK','manager','Majo','Maly','Brno','','','');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-12-02 17:20:55
